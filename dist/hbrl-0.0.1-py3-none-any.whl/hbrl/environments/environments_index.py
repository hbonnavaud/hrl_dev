from enum import Enum


class EnvironmentIndex(Enum):
    GRID_WORLD = "grid_world"
    POINT_MAZE = "point_maze"
    ANT_MAZE = "ant_maze"
